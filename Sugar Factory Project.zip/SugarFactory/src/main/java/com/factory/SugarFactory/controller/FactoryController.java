package com.factory.SugarFactory.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.factory.SugarFactory.model.Staff;
import com.factory.SugarFactory.model.Workers;
import com.factory.SugarFactory.service.FactoryService;

@RestController
public class FactoryController {

	@Autowired
	FactoryService service;

	@GetMapping("/a1")
	public List<Staff> getWorkersData() {
		return service.getWorkersData();
	}

	@PostMapping("/a2")
	public String insertWorkersData(@RequestBody List<Workers> list) {
		String msg = service.insertWorkersData(list);
		return msg;
	}

	@GetMapping("/a3")
	public List<Workers> getWorkersName() {
		return service.getWorkersName();
	}

	@GetMapping("/a4")
	public Workers loadSingleWorkersData() {
		return service.loadSingleWorkersData();
	}

	@GetMapping("/a5")
	public Workers getSingleWorkerData() {
		return service.getSingleWorkerData();
	}

	@PutMapping("/a6")
	public String updateWorkersData(@RequestBody List<Workers> list) {
		String msg = service.updateWorkersData(list);
		return msg;
	}

	@PostMapping("/a7")
	public String persistingData(@RequestBody List<Workers> a1) {

		System.out.println("Persisted Data...");

		return service.persistingData(a1);
	}

	@PostMapping("/a8")
	public String updateORsaveData(@RequestBody List<Workers> a2) {

		System.out.println("Update or save data...");

		return service.updateORsaveData(a2);
	}

	@PostMapping("/a9")
	public String mergeStudentData(@RequestBody List<Workers> a3) {

		System.out.println("Data merging..");
		return service.mergeStudentData(a3);
	}

	@PostMapping("/a10")
	public String checkEqualData(@RequestBody List<Workers> a4) {

		return service.checkEqualData(a4);

	}

	@RequestMapping("/a11")
	public List<Workers> lessthanData() {
		return service.lessthanData();

	}

	@RequestMapping("/a12")
	public List<Workers> greaterThanData() {
		return service.greaterThanData();

	}

	@RequestMapping("/a13")
	public List<Workers> greaterThanEqualto() {
		return service.greaterThanEqualto();

	}

	@GetMapping("/a14")
	public List<Workers> lessThanEqualto() {
		return service.lessThanEqualto();

	}

	@RequestMapping("/a15")
	public List<Workers> notEqualTOData() {
		return service.notEqualTOData();

	}

	@RequestMapping("/a16")
	public List<Workers> sameWorkersData() {
		return service.sameWorkersData();
	}

	@RequestMapping("/a17")
	public List<Workers> idSameWorkersData() {
		return service.idSameWorkersData();

	}

	@GetMapping("/a18")
	public List<Workers> sameWorkersName() {

		return service.sameWorkersName();
	}

	@RequestMapping("/a19")
	public List<Workers> equalORnullData() {

		return service.equalORnullData();
	}

	@RequestMapping("/a20")
	public List<Workers> sizeGEdata() {

		return service.sizeGEdata();
	}

	@GetMapping("/a21")
	public List<Workers> betweenWorkersData() {

		return service.betweenWorkersData();
	}

	@RequestMapping("/a22")
	public List<Workers> notEualORnullData() {

		return service.notEualORnullData();
	}

	@RequestMapping("/a24")
	public List<Workers> sizeLessThanEqualTo() {

		return service.sizeLessThanEqualTo();

	}

}
