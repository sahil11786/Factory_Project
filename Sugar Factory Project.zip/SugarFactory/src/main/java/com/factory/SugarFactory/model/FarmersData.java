package com.factory.SugarFactory.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class FarmersData {

	private int id;
	private String name;
	private String age;
	private String loc;
	private String totalBill;
	private String pendingBill;
	private String ton;
	
	@Id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getTotalBill() {
		return totalBill;
	}
	public void setTotalBill(String totalBill) {
		this.totalBill = totalBill;
	}
	public String getPendingBill() {
		return pendingBill;
	}
	public void setPendingBill(String pendingBill) {
		this.pendingBill = pendingBill;
	}
	public String getTon() {
		return ton;
	}
	public void setTon(String ton) {
		this.ton = ton;
	}
	@Override
	public String toString() {
		return "FarmersData [id=" + id + ", name=" + name + ", age=" + age + ", loc=" + loc + ", totalBill=" + totalBill
				+ ", pendingBill=" + pendingBill + ", ton=" + ton + "]";
	}
	
	
	
}
