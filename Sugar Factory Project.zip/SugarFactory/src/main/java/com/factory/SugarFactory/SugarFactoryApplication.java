package com.factory.SugarFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SugarFactoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SugarFactoryApplication.class, args);
	}

}
