package com.factory.SugarFactory.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Staff {
	
	private int id;
	private	String name;
	private	String age;
	private	String position;
	private	String shift;
	private	String loc;
	private	String salary; 
	
	@Id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Staff [id=" + id + ", name=" + name + ", age=" + age + ", position=" + position + ", shift=" + shift
				+ ", loc=" + loc + ", salary=" + salary + "]";
	}
	
	

}
