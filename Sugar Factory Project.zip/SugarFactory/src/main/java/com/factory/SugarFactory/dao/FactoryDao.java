package com.factory.SugarFactory.dao;

import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.factory.SugarFactory.model.Staff;
import com.factory.SugarFactory.model.Workers;

@Repository
public class FactoryDao {

	@Autowired
	SessionFactory sf;

	public List<Staff> getWorkersData() {

		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Staff.class);
		List<Staff> list = crt.list();

		return list;
	}

	public String insertWorkersData(List<Workers> list) {
		Session session = sf.openSession();
		Transaction ts = session.beginTransaction();
		for (Workers workers : list) {
			session.save(workers);
		}
		ts.commit();
		session.close();
		return "Data Inserted Successfully...!!";
	}

	public List<Workers> getWorkersName() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.eq("name", "Sagar Kawale"));
		List<Workers> list = crt.list();
		return list;
	}

	public Workers loadSingleWorkersData() {
		Session session = sf.openSession();
		Workers s1 = session.load(Workers.class, 1122);
		return s1;
	}

	public Workers getSingleWorkerData() {
		Session session = sf.openSession();
		Workers s2 = session.get(Workers.class, 1121);
		return s2;
	}

	public String updateWorkersData(List<Workers> list) {
		Session session = sf.openSession();
		Transaction ts = session.beginTransaction();
		for (Workers workers : list) {
			session.update(list);
		}
		ts.commit();
		return "Workers Data Updated Successfully..";
	}

	public String persistingData(List<Workers> a1) {
		Session session = sf.openSession();
		Transaction ts = session.beginTransaction();
		for (Workers ww : a1) {
			session.persist(ww);
		}
		ts.commit();
		System.out.println("Data Persisted..");
		return "Data Persisted..";

	}

	public String updateORsaveData(List<Workers> a2) {
		Session session = sf.openSession();
		Transaction ts = session.beginTransaction();
		for (Workers workers : a2) {
			session.saveOrUpdate(a2);
		}
		ts.commit();
		return "Data Save OR update successfully..";
	}

	public String mergeStudentData(List<Workers> a3) {
		Session session = sf.openSession();
		Transaction ts = session.beginTransaction();
		for (Workers workers : a3) {
			session.merge(a3);
		}
		ts.commit();
		return "Data Merged..";
	}

	@SuppressWarnings("unlikely-arg-type")
	public String checkEqualData(List<Workers> a4) {
		Session session = sf.openSession();
		Transaction ts = session.beginTransaction();
		for (Workers workers : a4) {
			session.equals(a4);
		}
		return "Data Already Exist";
	}

	public List<Workers> lessthanData() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.lt("salary", "15000"));
		List<Workers> list = crt.list();
		return list;
	}

	public List<Workers> greaterThanData() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.gt("salary", "15000"));
		List<Workers> list = crt.list();
		return list;
	}

	public List<Workers> greaterThanEqualto() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.ge("salary", "20000"));
		List<Workers> list = crt.list();
		return list;
	}

	public List<Workers> lessThanEqualto() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.lt("salary", "20000"));
		List<Workers> list = crt.list();
		return list;
	}

	public List<Workers> notEqualTOData() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.ne("shift", "Day"));
		List<Workers> list = crt.list();
		return list;
	}

	public List<Workers> sameWorkersData() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.like("loc", "Kachrewadi"));
		List<Workers> list = crt.list();
		return list;
	}

	public List<Workers> idSameWorkersData() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.idEq(1121));
		List<Workers> list = crt.list();
		return list;
	}

	public List<Workers> sameWorkersName() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.ilike("name", "Sagar Kawale"));
		List<Workers> list = crt.list();
		return list;
	}

	public List<Workers> equalORnullData() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.eqOrIsNull("work", "Fitter"));
		List<Workers> list = crt.list();
		return list;

	}

	public List<Workers> sizeGEdata() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.sizeGe("name", 4));
		List<Workers> list = crt.list();
		return list;

	}

	public List<Workers> betweenWorkersData() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.between("salary", "15000", "20000"));
		List<Workers> list = crt.list();
		return list;
	}

	public List<Workers> notEualORnullData() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.neOrIsNotNull("age", "25"));
		List<Workers> list = crt.list();
		return list;
	}

	public List<Workers> sizeLessThanEqualTo() {
		Session session = sf.openSession();
		Criteria crt = session.createCriteria(Workers.class);
		crt.add(Restrictions.sizeLe("name", 4));
		List<Workers> list = crt.list();
		return list;
	}
}
