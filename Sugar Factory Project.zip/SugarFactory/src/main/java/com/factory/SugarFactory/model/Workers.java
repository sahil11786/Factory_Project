package com.factory.SugarFactory.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Workers {

	private int id;
	private String name;
	private String age;
	private String work;
	private String loc;
	private String salary;
	private	String shift;
	private String qualification;
	
	@Id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getWork() {
		return work;
	}
	public void setWork(String work) {
		this.work = work;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getShift() {
		return shift;
	}
	public void setShift(String shift) {
		this.shift = shift;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	@Override
	public String toString() {
		return "Workers [id=" + id + ", name=" + name + ", age=" + age + ", work=" + work + ", loc=" + loc + ", salary="
				+ salary + ", shift=" + shift + ", qualification=" + qualification + "]";
	}
	
	
	
}
