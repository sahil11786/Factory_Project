package com.factory.SugarFactory.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.factory.SugarFactory.dao.FactoryDao;
import com.factory.SugarFactory.model.Staff;
import com.factory.SugarFactory.model.Workers;

@Service
public class FactoryService {

	@Autowired
	FactoryDao dao;

	public List<Staff> getWorkersData() {
		// TODO Auto-generated method stub
		return dao.getWorkersData();
	}

	public String insertWorkersData(List<Workers> list) {
		String msg = dao.insertWorkersData(list);
		return msg;
	}

	public List<Workers> getWorkersName() {
		// TODO Auto-generated method stub
		return dao.getWorkersName();
	}

	public Workers loadSingleWorkersData() {
		// TODO Auto-generated method stub
		return dao.loadSingleWorkersData();
	}

	public Workers getSingleWorkerData() {
		// TODO Auto-generated method stub
		return dao.getSingleWorkerData();
	}

	public String updateWorkersData(List<Workers> list) {
		// TODO Auto-generated method stub
		String msg = dao.updateWorkersData(list);
		return msg;
	}

	public String persistingData(List<Workers> a1) {
		// TODO Auto-generated method stub
		return dao.persistingData(a1);
	}

	public String updateORsaveData(List<Workers> a2) {
		// TODO Auto-generated method stub
		return dao.updateORsaveData(a2);
	}

	public String mergeStudentData(List<Workers> a3) {
		// TODO Auto-generated method stub
		return dao.mergeStudentData(a3);
	}

	public String checkEqualData(List<Workers> a4) {
		// TODO Auto-generated method stub
		return dao.checkEqualData(a4);
	}

	public List<Workers> lessthanData() {
		// TODO Auto-generated method stub
		return dao.lessthanData();
	}

	public List<Workers> greaterThanData() {
		// TODO Auto-generated method stub
		return dao.greaterThanData();
	}

	public List<Workers> greaterThanEqualto() {
		// TODO Auto-generated method stub
		return dao.greaterThanEqualto();
	}

	public List<Workers> lessThanEqualto() {
		// TODO Auto-generated method stub
		return dao.lessThanEqualto();
	}

	public List<Workers> notEqualTOData() {
		// TODO Auto-generated method stub
		return dao.notEqualTOData();
	}

	public List<Workers> sameWorkersData() {
		// TODO Auto-generated method stub
		return dao.sameWorkersData();
	}

	public List<Workers> idSameWorkersData() {
		// TODO Auto-generated method stub
		return dao.idSameWorkersData();
	}

	public List<Workers> sameWorkersName() {
		// TODO Auto-generated method stub
		return dao.sameWorkersName();
	}

	public List<Workers> equalORnullData() {
		// TODO Auto-generated method stub
		return dao.equalORnullData();
	}

	public List<Workers> sizeGEdata() {
		// TODO Auto-generated method stub
		return dao.sizeGEdata();
	}

	public List<Workers> betweenWorkersData() {
		// TODO Auto-generated method stub
		return dao.betweenWorkersData();
	}

	public List<Workers> notEualORnullData() {
		// TODO Auto-generated method stub
		return dao.notEualORnullData();
	}

	public List<Workers> sizeLessThanEqualTo() {
		// TODO Auto-generated method stub
		return dao.sizeLessThanEqualTo();
	}

}
